package harry.potter;

import harry.potter.controller.datasource.HouseDatasource;
import harry.potter.controller.datasource.StudentDatasource;
import harry.potter.controller.service.StudentService;
import harry.potter.view.MainWindow;

public class Main {

//    private static HouseDatasource hd = new HouseDatasource();
//
//    private static StudentService test = new StudentService();

    public static void main(String[] args) {

        MainWindow startup = new MainWindow();
//        test.updateStudent("ttt", 25, "VALAMI CHARACTER 1", "iiii");
//        test.addStudent(2, "SSSS", "AAAA");
//        Main.listStudents();
//        test.changeCharacter("AAAA", "WWWWW");
//        Main.listStudents();
    }

//    private static void listStudents() {
//
//        List<Student> students = test.listStudents();
//        for (Student student : students) {
//            System.out.println(" ID: " + student.getId() + " AGE: " + student.getAge() +
//                    " NAME: " + student.getName() + " Character:" + student.getCharacter().toString());
//        }
//    }
}
